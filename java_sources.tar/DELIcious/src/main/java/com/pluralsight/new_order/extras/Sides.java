package com.pluralsight.new_order.extras;

public class Sides {
    String type;

    public Sides(String type) {
        this.type = type;
    }
}
