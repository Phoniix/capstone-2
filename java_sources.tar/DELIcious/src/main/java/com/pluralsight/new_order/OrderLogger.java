package com.pluralsight.new_order;

public class OrderLogger {
}
