package com.pluralsight.new_order;

import java.util.Scanner;

public interface SizeInterface {
    double calcPriceFromSize(Size size);

}
