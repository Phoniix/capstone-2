package com.pluralsight.new_order.sandwiches.sandwich_contents;

import com.pluralsight.design.Design;
import com.pluralsight.new_order.Size;
import com.pluralsight.new_order.SizeInterface;

import java.util.*;

public class Topping implements SizeInterface {
    private final double unitCost; // Cost when portion size is SMALL.
    private final String name;
    String groupType;

    // Defined Constructor
    public Topping (String groupType, String name, double unitCost) {
        this.unitCost = unitCost;
        this.name = name;
        this.groupType = groupType;
    }

    // Size -> price conversion
    public double calcPriceFromSize(Size sandwichSize) {
        return switch (sandwichSize) {
            case SMALL -> 1 * this.unitCost;
            case MEDIUM -> 2 * this.unitCost * 2;
            case LARGE -> 3 * this.unitCost * 3;
        };
    }
    public double totalToppingPrice (List<Topping> toppings, Size sandwichSize) {
        double sum = 0;
        for (Topping topping : toppings) {
            sum += topping.calcPriceFromSize(sandwichSize);
        } return sum;
    }


    // Hardcoded Arraylist of ALL toppings
    public static List<Topping> allToppings () {
        List<Topping> allToppings = new ArrayList<>();
        allToppings.add(new Topping("MEAT", "STEAK", 1.00));
        allToppings.add(new Topping("MEAT", "HAM", 1.00));
        allToppings.add(new Topping("MEAT", "SALAMI", 1.00));
        allToppings.add(new Topping("MEAT", "ROAST BEEF", 1.00));
        allToppings.add(new Topping("MEAT", "CHICKEN", 1.00));
        allToppings.add(new Topping("MEAT", "BACON", 1.00));

        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA STEAK", 0.50));
        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA HAM", 0.50));
        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA SALAMI", 0.50));
        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA ROAST BEEF", 0.50));
        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA CHICKEN", 0.50));
        allToppings.add(new Topping("EXTRA_MEAT", "EXTRA BACON", 0.50));

        allToppings.add(new Topping("CHEESE", "AMERICAN", 0.75));
        allToppings.add(new Topping("CHEESE", "PROVOLONE", 0.75));
        allToppings.add(new Topping("CHEESE", "CHEDDAR", 0.75));
        allToppings.add(new Topping("CHEESE", "SWISS", 0.75));

        allToppings.add(new Topping("EXTRA_CHEESE", "EXTRA AMERICAN", 0.30));
        allToppings.add(new Topping("EXTRA_CHEESE", "EXTRA PROVOLONE", 0.30));
        allToppings.add(new Topping("EXTRA_CHEESE", "EXTRA CHEDDAR", 0.30));
        allToppings.add(new Topping("EXTRA_CHEESE", "EXTRA AMERICAN", 0.30));

        allToppings.add(new Topping("REGULAR", "LETTUCE", 0.00));
        allToppings.add(new Topping("REGULAR", "PEPPERS", 0.00));
        allToppings.add(new Topping("REGULAR", "ONIONS", 0.00));
        allToppings.add(new Topping("REGULAR", "TOMATOES", 0.00));
        allToppings.add(new Topping("REGULAR", "JALAPENOS", 0.00));
        allToppings.add(new Topping("REGULAR", "CUCUMBERS", 0.00));
        allToppings.add(new Topping("REGULAR", "PICKLES", 0.00));
        allToppings.add(new Topping("REGULAR", "GUACAMOLE", 0.00));
        allToppings.add(new Topping("REGULAR", "MUSHROOMS", 0.00));

        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA LETTUCE", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA PEPPERS", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA ONIONS", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA TOMATOES", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA JALAPENOS", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA CUCUMBERS", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA PICKLES", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA GUACAMOLE", 0.00));
        allToppings.add(new Topping("EXTRA_REGULAR", "EXTRA MUSHROOMS", 0.00));

        allToppings.add(new Topping("SAUCE", "MAYO", 0.00));
        allToppings.add(new Topping("SAUCE", "MUSTARD", 0.00));
        allToppings.add(new Topping("SAUCE", "KETCHUP", 0.00));
        allToppings.add(new Topping("SAUCE", "RANCH", 0.00));
        allToppings.add(new Topping("SAUCE", "THOUSAND ISLAND", 0.00));
        allToppings.add(new Topping("SAUCE", "VINAIGRETTE", 0.00));

        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA MAYO", 0.00));
        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA MUSTARD", 0.00));
        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA KETCHUP", 0.00));
        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA RANCH", 0.00));
        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA THOUSAND ISLAND", 0.00));
        allToppings.add(new Topping("EXTRA_SAUCE", "EXTRA VINAIGRETTE", 0.00));

        allToppings.add(new Topping("SIDE", "AU JUS (GRAVY)", 0.00));
        allToppings.add(new Topping("SIDE", "AU JUS (GRAVY)", 0.00));

        return allToppings;
    }

    // Methods worked for UI purposes
    public static List<String> allGroupTypes (boolean isExtra) {
        List<String> groups = new ArrayList<>();
        if (!isExtra) groups.add("MEAT");
        if (isExtra) groups.add("EXTRA_MEAT");
        if (!isExtra) groups.add("CHEESE");
        if (isExtra) groups.add("EXTRA_CHEESE");
        if (!isExtra) groups.add("REGULAR");
        if (isExtra) groups.add("EXTRA_REGULAR");
        if (!isExtra) groups.add("SAUCE");
        if (isExtra) groups.add("EXTRA_SAUCE");
        return groups;
    }
    public static LinkedHashMap<Integer, String> printGroupType(List<String> groupTypes) {
        LinkedHashMap <Integer, String> selectedTypes = new LinkedHashMap<>();
        int counter = 0;
            for (String group : groupTypes) {
                counter++;
                System.out.println(counter + ") "  + group);
                selectedTypes.put(counter, group);
            }
        return selectedTypes;
    }
    public static LinkedHashMap<Integer, Topping> printToppingFromGroupType (LinkedHashMap<Integer, String> groupTypes, int choice, Size sandwichSize) {
        LinkedHashMap<Integer, Topping> toppingsByGroup = new LinkedHashMap<>();
        int counter = 0;
        for (Topping topping : allToppings()) {
            if (groupTypes.get(choice).equals(topping.getGroupType())) {
                counter++;
                System.out.println(counter + ") " + topping);
                toppingsByGroup.put(counter, topping);
            }
        }
         return toppingsByGroup;
    }
    public static Topping selectedTopping (int choice, LinkedHashMap<Integer, Topping> availableToppings) {
        return availableToppings.get(choice);
    }
    public static List<Topping> getToppings(Scanner scanner, Size sandwichSize, boolean isExtra) {
        List<Topping> chosenToppings = new ArrayList<>();
        while (true) {
            Design.titleNewLineTop();
            Design.systemMessage("What toppings would you like?\n" +
                    "Press 0 to finish.", false);
            LinkedHashMap<Integer, String> viewableTypes = printGroupType(allGroupTypes(isExtra));
            int choice =  Design.getIntWithMaxMin(scanner, false, "", true, 0, viewableTypes.size());
            Design.titleLineBottom();
            if (choice == 0) break;

            Design.titleNewLineTop();
            Design.systemMessage("What toppings would you like?\n" +
                    "Press 0 to finish.", false
            );
            LinkedHashMap<Integer, Topping> viewableToppings = printToppingFromGroupType(viewableTypes, choice, sandwichSize);
            choice = Design.getIntWithMaxMin(scanner, false, "", true, 0, viewableToppings.size());
            Design.titleLineBottom();
            if (choice == 0) break;

            chosenToppings.add(selectedTopping(choice, viewableToppings));
        }
        return chosenToppings;
    }

    // Getters
    public String getGroupType() {
        return groupType;
    }

    // toString
    @Override
    public String toString() {
        return name;
    }
}
